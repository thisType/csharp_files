﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment3.Models
{
    public class Geo
    {
        public string lat {  get; set; }
        public string lng { get; set; }
    }
}
