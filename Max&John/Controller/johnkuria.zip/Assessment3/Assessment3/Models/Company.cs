﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment3.Models
{
    public class Company
    {

        public string name {  get; set; }
        public string catchPhrase {  get; set; }
        public string bs {  get; set; }
    }
}
